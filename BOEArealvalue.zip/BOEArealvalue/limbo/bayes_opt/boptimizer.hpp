//| Copyright Inria May 2015
//| This project has received funding from the European Research Council (ERC) under
//| the European Union's Horizon 2020 research and innovation programme (grant
//| agreement No 637972) - see http://www.resibots.eu
//|
//| Contributor(s):
//|   - Jean-Baptiste Mouret (jean-baptiste.mouret@inria.fr)
//|   - Antoine Cully (antoinecully@gmail.com)
//|   - Konstantinos Chatzilygeroudis (konstantinos.chatzilygeroudis@inria.fr)
//|   - Federico Allocati (fede.allocati@gmail.com)
//|   - Vaios Papaspyros (b.papaspyros@gmail.com)
//|   - Roberto Rama (bertoski@gmail.com)
//|
//| This software is a computer library whose purpose is to optimize continuous,
//| black-box functions. It mainly implements Gaussian processes and Bayesian
//| optimization.
//| Main repository: http://github.com/resibots/limbo
//| Documentation: http://www.resibots.eu/limbo
//|
//| This software is governed by the CeCILL-C license under French law and
//| abiding by the rules of distribution of free software.  You can  use,
//| modify and/ or redistribute the software under the terms of the CeCILL-C
//| license as circulated by CEA, CNRS and INRIA at the following URL
//| "http://www.cecill.info".
//|
//| As a counterpart to the access to the source code and  rights to copy,
//| modify and redistribute granted by the license, users are provided only
//| with a limited warranty  and the software's author,  the holder of the
//| economic rights,  and the successive licensors  have only  limited
//| liability.
//|
//| In this respect, the user's attention is drawn to the risks associated
//| with loading,  using,  modifying and/or developing or reproducing the
//| software by the user in light of its specific status of free software,
//| that may mean  that it is complicated to manipulate,  and  that  also
//| therefore means  that it is reserved for developers  and  experienced
//| professionals having in-depth computer knowledge. Users are therefore
//| encouraged to load and test the software's suitability as regards their
//| requirements in conditions enabling the security of their systems and/or
//| data to be ensured and,  more generally, to use and operate it in the
//| same conditions as regards security.
//|
//| The fact that you are presently reading this means that you have had
//| knowledge of the CeCILL-C license and that you accept its terms.
//|
#ifndef LIMBO_BAYES_OPT_BOPTIMIZER_HPP
#define LIMBO_BAYES_OPT_BOPTIMIZER_HPP

#include <algorithm>
#include <iostream>
#include <iterator>

#define USE_NLOPT;

#include <boost/parameter/aux_/void.hpp>

#include <Eigen/Core>

#include "bayes_opt/bo_base.hpp"
#include "tools/macros.hpp"
#include "tools/random_generator.hpp"

#ifdef USE_NLOPT

#include "opt/nlopt_no_grad.hpp"

#elif defined USE_LIBCMAES
#include "opt/cmaes.hpp>
#else
#include "opt/grid_search.hpp"
#endif

#include "../../galgo/Galgo.hpp"
#include "../../galgo/TestFunction.hpp"

#include <sys/time.h>

using vec_t = Eigen::VectorXd;
using mat_t = Eigen::MatrixXd;

#define ASSIGNMENT_OP <<


///**************** configuration galgo real value ***************///
template <typename _TYPE>
void set_my_config(galgo::ConfigInfo<_TYPE>& config)
{
  // override some defaults
  config.mutinfo._sigma           = 1.0;
  config.mutinfo._sigma_lowest    = 0.001; //cannot too small that change nothing
  config.mutinfo._ratio_boundary  = 0.10;

  config.covrate = 0.1;  // 0.0 if no cros-over
  config.mutrate = 0.8; // mutation rate usually is 1.0 for real-valued
  config.recombination_ratio = 0.60; //Real Valued crossover ratio, can't be 0.5 because 0.5 will generate two same offsprings after Xover

  config.elitpop      = 1;
  config.tntsize      = 2; //k-tournament size k=2/4, higher value higher pressure
  config.Selection    = TNT;
  config.CrossOver    = RealValuedSimpleArithmeticRecombination;
  config.mutinfo._type = galgo::MutationType::MutationGAM_UncorrelatedNStepSizeBoundary;

  config.popsize  = 10;
  config.nbgen    = 125; //The num of gens for EA, 131+19, 125+25, 122+28
  config.output   = true;
}

namespace limbo
{
  namespace defaults
  {
    struct bayes_opt_boptimizer
    {
      BO_PARAM(int, hp_period, -1);
    };
  }

  BOOST_PARAMETER_TEMPLATE_KEYWORD(acquiopt)

  namespace bayes_opt
  {

    using boptimizer_signature = boost::parameter::parameters< boost::parameter::optional< tag::acquiopt >, boost::parameter::optional< tag::statsfun >, boost::parameter::optional< tag::initfun >, boost::parameter::optional< tag::acquifun >, boost::parameter::optional< tag::stopcrit >, boost::parameter::optional< tag::modelfun>>;

    // clang-format off
    /**
    The classic Bayesian optimization algorithm.

    \rst
    References: :cite:`brochu2010tutorial,Mockus2013`
    \endrst

    This class takes the same template parameters as BoBase. It adds:
    \rst
    +---------------------+------------+----------+---------------+
    |type                 |typedef     | argument | default       |
    +=====================+============+==========+===============+
    |acqui. optimizer     |acquiopt_t  | acquiopt | see below     |
    +---------------------+------------+----------+---------------+
    \endrst

    The default value of acqui_opt_t is:
    - ``opt::NLOptNoGrad<Params, nlopt::GN_DIRECT_L_RAND>`` if NLOpt was found in `waf configure`
    - ``opt::Cmaes<Params>`` if libcmaes was found but NLOpt was not found
    - ``opt::GridSearch<Params>`` otherwise (please do not use this: the algorithm will not work as expected!)
    */
    template <class Params,
              class A1 = boost::parameter::void_,
              class A2 = boost::parameter::void_,
              class A3 = boost::parameter::void_,
              class A4 = boost::parameter::void_,
              class A5 = boost::parameter::void_,
              class A6 = boost::parameter::void_>
    // clang-format on
    class BOptimizer
        : public BoBase< Params, A1, A2, A3, A4, A5, A6 >
    {
      public:

      //            explicit BOptimizer() {}

      // defaults
      struct defaults
      {
        using acquiopt_t = opt::NLOptNoGrad< Params, nlopt::GN_DIRECT_L_RAND >;
        //#ifdef USE_NLOPT
        //                using acquiopt_t = opt::NLOptNoGrad<Params, nlopt::GN_DIRECT_L_RAND>;
        //#elif defined(USE_LIBCMAES)
        //                using acquiopt_t = opt::Cmaes<Params>;
        //#else
        //#warning NO NLOpt, and NO Libcmaes: the acquisition function will be optimized by a grid search algorithm (which is usually bad). Please install at least NLOpt or libcmaes to use limbo!.
        //                using acquiopt_t = opt::GridSearch<Params>;
        //#endif
      };
      /// link to the corresponding BoBase (useful for typedefs)
      using base_t = BoBase< Params, A1, A2, A3, A4, A5, A6 >;
      using model_t = typename base_t::model_t;
      using acquisition_function_t = typename base_t::acquisition_function_t;
      // extract the types
      using args = typename boptimizer_signature::bind< A1, A2, A3, A4, A5, A6 >::type;
      using acqui_optimizer_t = typename boost::parameter::binding< args, tag::acquiopt, typename defaults::acquiopt_t >::type;

      /// The main function (run the Bayesian optimization algorithm)
      template <typename StateFunction, typename AggregatorFunction = FirstElem>
      void optimize(
          const StateFunction &sfun,
          const AggregatorFunction &afun = AggregatorFunction(),
          bool reset = true)
      {
        this->_init(sfun, afun, reset); //initial sampling

        if (!this->_observations.empty())
        {
          _model.compute(this->_samples, this->_observations);
        }
        else
        {
          _model = model_t(StateFunction::dim_in(), StateFunction::dim_out());
        }

        acqui_optimizer_t acqui_optimizer;

        ///********** Evolutionary Algorithm ************///
        int init_bo_gens = Params::init_randomsampling::samples();
        //1s -> 19*10 (180+10), 10s -> 25*10 (240+10), 100s -> 28 (270+10)
        int bo_gens = 240; //B.O. evaluations after init, 240+10
        int switch_no = init_bo_gens + bo_gens; //The num of evaluations for switching from B.O. to E.A.
        int ea_gens = 125; //The num of gens for EA, 131+19, 125+25, 122+28
        int pop_size = 10; //population size each gen for EA

        struct timeval timeStartBO, timeEndBO;
        double timeDiffBO;

        std::ofstream ctime;
        ctime.open("../ctime.txt", std::ios::app);
        // CONFIG
        using _TYPE = float;    // Suppport float, double, char, int, long, ... for parameters
        const int NBIT = 32;    // Has to remain between 1 and 64, 32:float
        galgo::ConfigInfo<_TYPE> config;  // A new instance of config get initial defaults
        set_my_config<_TYPE>(config);    // Override some defaults
        while (not this->_stop(*this, afun))
        {
//          std::cout << "total_iterations : " << this->_total_iterations<< std::endl;
          ///********** Evolutionary Algorithm ************///
          if (this->_total_iterations == (switch_no + 1)) //10
          {
            // initializing parameters lower and upper bounds
            std::cout << "total_iterations : " << this->_total_iterations<< std::endl;
            galgo::Parameter< _TYPE, NBIT > par1({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par2({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par3({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par4({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par5({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par6({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par7({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par8({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par9({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par10({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par11({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par12({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par13({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par14({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par15({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par16({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par17({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par18({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par19({(_TYPE)0.0, (_TYPE)1.0});
            galgo::Parameter< _TYPE, NBIT > par20({(_TYPE)0.0, (_TYPE)1.0});

//            config.Objective = AckleyObjective< _TYPE >::Objective; //1#
            config.Objective = SchwefelObjective< _TYPE >::Objective; //2#
//            config.Objective = EllipsoidObjective< _TYPE >::Objective; //3#
//            config.Objective = SphereObjective< _TYPE >::Objective; //4#
//            config.Objective = RosenbrockObjective< _TYPE >::Objective; //5#
//            config.Objective = MichalewiczObjective< _TYPE >::Objective; //6#
//            config.Objective = StyblinskiTangObjective< _TYPE >::Objective; //7#
//              config.Objective = RastriginObjective< _TYPE >::Objective;
//              config.Objective = GriewankObjective< _TYPE >::Objective;


            galgo::GeneticAlgorithm< _TYPE > ga(config,
                                                par1,
                                                par2,
                                                par3,
                                                par4,
                                                par5,
                                                par6,
                                                par7,
                                                par8,
                                                par9,
                                                par10,
                                                par11,
                                                par12,
                                                par13,
                                                par14,
                                                par15,
                                                par16,
                                                par17,
                                                par18,
                                                par19,
                                                par20
                                                    );
            ga.run();
            //trigger the max iteration
            this->_current_iteration = switch_no + ea_gens;
            this->_total_iterations = switch_no + ea_gens;
            //this->_total_iterations = 70; //50 + 20
          }
          ///********** Bayesian Optimization ************///
          else
          {
            gettimeofday(&timeStartBO, NULL);

            acquisition_function_t acqui(_model, this->_current_iteration);

            auto acqui_optimization = [&](
                const Eigen::VectorXd &x,
                bool g)
            { return acqui(x, afun, g); };
            Eigen::VectorXd starting_point = tools::random_vector(StateFunction::dim_in(), Params::bayes_opt_bobase::bounded());

            // new samples are from the acquisition optimizer
            Eigen::VectorXd new_sample = acqui_optimizer(acqui_optimization,
                                                         starting_point,
                                                         Params::bayes_opt_bobase::bounded());

            ///Evaluate a sample and add the result to the 'database'(sample/observations vectors)--it does not update the model
            this->eval_and_add(sfun, new_sample);

            this->_update_stats(*this, afun);

            _model.add_sample(this->_samples.back(), this->_observations.back());

            if (Params::bayes_opt_boptimizer::hp_period() > 0 && (this->_current_iteration + 1) % Params::bayes_opt_boptimizer::hp_period() == 0)
            {
              _model.optimize_hyperparams();
            }

            //std::cout << "_current_iterations: " << this->_current_iteration << std::endl;

            this->_current_iteration++;
            this->_total_iterations++;

            gettimeofday(&timeEndBO, NULL);
            //tv_sec: value of second, tv_usec: value of microsecond
            timeDiffBO = 1000000 * (timeEndBO.tv_sec - timeStartBO.tv_sec) + timeEndBO.tv_usec - timeStartBO.tv_usec;
            timeDiffBO /= 1000;
//            std::cout << "timeDiffBO: " << timeDiffBO << std::endl;

            ctime << std::fixed << timeDiffBO << std::endl;
          }
          ///********** Bayesian Optimization ************///
        }
      }

      /// return the best observation so far (i.e. max(f(x)))
      template <typename AggregatorFunction = FirstElem>
      const Eigen::VectorXd &best_observation(const AggregatorFunction &afun = AggregatorFunction()) const
      {
        auto rewards = std::vector< double >(this->_observations.size());
        std::transform(this->_observations.begin(),
                       this->_observations.end(),
                       rewards.begin(),
                       afun);
        auto max_e = std::max_element(rewards.begin(), rewards.end());
        return this->_observations[std::distance(rewards.begin(), max_e)];
      }

      /// return the best sample so far (i.e. the argmax(f(x)))
      template <typename AggregatorFunction = FirstElem>
      const Eigen::VectorXd &best_sample(const AggregatorFunction &afun = AggregatorFunction()) const
      {
        auto rewards = std::vector< double >(this->_observations.size());
        std::transform(this->_observations.begin(),
                       this->_observations.end(),
                       rewards.begin(),
                       afun);
        auto max_e = std::max_element(rewards.begin(), rewards.end());
        return this->_samples[std::distance(rewards.begin(), max_e)];
      }

      const model_t &model() const
      {
        return _model;
      }

      protected:
      model_t _model;
    };

    namespace _default_hp
    {
      template <typename Params> using model_t = model::GPOpt< Params >;
      template <typename Params> using acqui_t = acqui::UCB< Params, model_t< Params>>;
    }

    /// A shortcut for a BOptimizer with UCB + GPOpt
    /// The acquisition function and the model CANNOT be tuned (use BOptimizer for this)
    template <class Params,
              class A1 = boost::parameter::void_,
              class A2 = boost::parameter::void_,
              class A3 = boost::parameter::void_,
              class A4 = boost::parameter::void_> using BOptimizerHPOpt = BOptimizer< Params, modelfun< _default_hp::model_t< Params>>, acquifun< _default_hp::acqui_t< Params>>, A1, A2, A3, A4 >;
  }
}
#endif
